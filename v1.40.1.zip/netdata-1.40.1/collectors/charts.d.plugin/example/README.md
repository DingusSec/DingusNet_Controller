<!--
title: "Example"
custom_edit_url: "https://github.com/netdata/netdata/edit/master/collectors/charts.d.plugin/example/README.md"
sidebar_label: "example-charts.d.plugin"
learn_status: "Published"
learn_topic_type: "References"
learn_rel_path: "Integrations/Monitor/Mock Collectors"
-->

# Example

If you want to understand how charts.d data collector functions, check out the [charts.d example](https://raw.githubusercontent.com/netdata/netdata/master/collectors/charts.d.plugin/example/example.chart.sh). 


