<!--
title: "checks.plugin"
custom_edit_url: "https://github.com/netdata/netdata/edit/master/collectors/checks.plugin/README.md"
sidebar_label: "checks.plugin"
learn_status: "Unpublished"
-->

# checks.plugin

A debugging plugin (by default it is disabled)


